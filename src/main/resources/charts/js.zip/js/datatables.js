function addDataTable(tableElement, queryString) {
    var search = /[&?]search=([^&]*)/.exec(queryString)
    if (!search) {
        search = ""
    }

    tableElement.DataTable(
        {
            "lengthMenu": [[20, 50, 100, -1], [20, 50, 100, "All"]],
            "info": false,
            "search": {
                "regex" : true,
                "search": search[1]
            },
            "columnDefs": [
                { "width": "20%", "targets": 0 }
            ]
        }
    )
}